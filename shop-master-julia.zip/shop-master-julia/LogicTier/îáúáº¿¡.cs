﻿using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;

namespace LogicTier
{
    public class Магазин : INotifyPropertyChanged
    {
        private ObservableCollection<ОбъектПозиция> _товары;

        private string _объектСМаксимальнойСтоимостьюКМ;
        private string _средняяСтоимостьКМДляКвартир;

        public string ОбъектСМаксимальнойСтоимостьюКМ
        {
            get => _объектСМаксимальнойСтоимостьюКМ;
            set
            {
                _объектСМаксимальнойСтоимостьюКМ = value;
                OnPropertyChanged(nameof(ОбъектСМаксимальнойСтоимостьюКМ));
            }
        }

        public string СредняяСтоимостьКМДляКвартир
        {
            get => _средняяСтоимостьКМДляКвартир;
            set
            {
                _средняяСтоимостьКМДляКвартир = value;
                OnPropertyChanged(nameof(СредняяСтоимостьКМДляКвартир));
            }
        }

        public Магазин(ObservableCollection<ОбъектПозиция> позиции)
        {
            _товары = позиции ?? new ObservableCollection<ОбъектПозиция>();
            ОбновитьРасчеты();
        }

        public ObservableCollection<ОбъектПозиция> СписокТоваров => _товары;

        public void ОбновитьРасчеты()
        {
            ОбъектСМаксимальнойСтоимостьюКМ = ВычислитьОбъектСМаксСтоимостьюКМ();
            СредняяСтоимостьКМДляКвартир = ВычислитьСреднююСтоимостьКМДляКвартир().ToString("F2");
        }

        private string ВычислитьОбъектСМаксСтоимостьюКМ()
        {
            if (_товары.Count == 0)
                return "Нет объектов";

            var maxItem = _товары.First();
            double maxznach = maxItem.Стоимость / (double)maxItem.Метраж;

            foreach (var item in _товары)
            {
                double current = item.Стоимость / (double)item.Метраж;
                if (current > maxznach)
                {
                    maxznach = current;
                    maxItem = item;
                }
            }

            return maxItem.ПредставлениеТовара;
        }

        private double ВычислитьСреднююСтоимостьКМДляКвартир()
        {
            var квартиры = _товары.Where(t => t.ТипСтроения.ToLower() == "квартира").ToList();
            if (квартиры.Count == 0)
                return 0;

            double total = квартиры.Sum(t => (double)t.Стоимость / t.Метраж);
            return total / квартиры.Count;
        }

        public event PropertyChangedEventHandler PropertyChanged;

        protected void OnPropertyChanged(string name)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
        }

    }
}