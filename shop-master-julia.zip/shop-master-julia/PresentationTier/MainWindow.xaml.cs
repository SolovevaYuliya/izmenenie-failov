﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Windows;
using System.Windows.Controls;
using Microsoft.Win32;
using DataTier;
using LogicTier;

namespace PresentationTier
{
    public partial class MainWindow : Window
    {
        private ObservableCollection<ОбъектПозиция> товары = new ObservableCollection<ОбъектПозиция>();
        private Магазин магазин;

        public MainWindow()
        {
            InitializeComponent();
            товары = new ObservableCollection<ОбъектПозиция>();
            магазин = new Магазин(товары);

            // Устанавливаем DataContext для привязки
            this.DataContext = магазин;
        }

        // Кнопка для поиска по фильтру
        private void SearchBtn_Click1(object sender, RoutedEventArgs e)
        {
            // Открываем диалог выбора файла
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Текстовые файлы (*.txt)|*.txt|JSON файлы (*.json)|*.json|Все файлы (*.*)|*.*";

            if (openFileDialog.ShowDialog() == true)
            {
                string путьКФайлу = openFileDialog.FileName;

                // Получаем выбранный критерий из ComboBox
                if (CodeComboBox.SelectedItem is ComboBoxItem выбранныйЭлемент)
                {
                    string выбранныйКритерий = выбранныйЭлемент.Content.ToString();
                    string значениеДляПоиска = SearchCodeTextBox.Text.Trim();

                    // Приводим имя критерия к нужному формату для поиска
                    string ключ = выбранныйКритерий switch
                    {
                        "Тип строения" => "ТипСтроения",
                        "Количество комнат" => "КоличествоКомнат",
                        "Метраж" => "Метраж",
                        "Стоимость" => "Стоимость",
                        _ => ""
                    };

                    if (string.IsNullOrWhiteSpace(ключ) || string.IsNullOrWhiteSpace(значениеДляПоиска))
                    {
                        MessageBox.Show("Выберите критерий и введите значение для поиска.");
                        return;
                    }

                    List<Объекты> всеОбъекты = new List<Объекты>();

                    try
                    {
                        if (Path.GetExtension(путьКФайлу).ToLower() == ".json")
                        {
                            // Загружаем из JSON
                            string json = File.ReadAllText(путьКФайлу);
                            всеОбъекты = System.Text.Json.JsonSerializer.Deserialize<List<Объекты>>(json);
                        }
                        else
                        {
                            // Загружаем из TXT
                            всеОбъекты = ВсеОбъекты.ПолучитьВсеОбъектыИзФайла(путьКФайлу);
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Ошибка чтения файла: {ex.Message}");
                        return;
                    }

                    // Теперь ищем по критерию
                    List<Объекты> найденныеОбъекты = ключ.ToLower() switch
                    {
                        "типстроения" => всеОбъекты.Where(obj => obj.ТипСтроения.Contains(значениеДляПоиска, StringComparison.OrdinalIgnoreCase)).ToList(),
                        "количествокомнат" when int.TryParse(значениеДляПоиска, out var комнаты) =>
                            всеОбъекты.Where(obj => obj.КоличествоКомнат == комнаты).ToList(),
                        "метраж" when int.TryParse(значениеДляПоиска, out var метраж) =>
                            всеОбъекты.Where(obj => obj.Метраж == метраж).ToList(),
                        "стоимость" when int.TryParse(значениеДляПоиска, out var стоимость) =>
                            всеОбъекты.Where(obj => obj.Стоимость == стоимость).ToList(),
                        _ => new List<Объекты>()
                    };

                    // Выводим результаты в ResultListBox
                    ResultListBox.ItemsSource = найденныеОбъекты.Select(obj => obj.ПредставлениеТовара).ToList();

                    if (найденныеОбъекты.Count == 0)
                    {
                        MessageBox.Show("Ничего не найдено по заданным критериям.");
                    }
                }
                else
                {
                    MessageBox.Show("Пожалуйста, выберите критерий поиска.");
                }
            }
        }


        // Кнопка для добавления нового объекта
        private void BtnAddItem_Click(object sender, RoutedEventArgs e)
        {
            if (NewComboBox.SelectedItem == null)
            {
                MessageBox.Show("Пожалуйста, выберите тип строения.");
                return;
            }

            if (string.IsNullOrWhiteSpace(CountRooms.Text) ||
                string.IsNullOrWhiteSpace(Metrazh.Text) ||
                string.IsNullOrWhiteSpace(Price.Text))
            {
                MessageBox.Show("Заполните все поля.");
                return;
            }

            if (!int.TryParse(CountRooms.Text, out int rooms) || rooms <= 0 ||
                !int.TryParse(Metrazh.Text, out int metrazh) || metrazh <= 0 ||
                !int.TryParse(Price.Text, out int price) || price <= 0)
            {
                MessageBox.Show("Введите корректные положительные числа в поля 'Комнаты', 'Метраж', 'Стоимость'.");
                return;
            }

            var selectedType = (NewComboBox.SelectedItem as ComboBoxItem)?.Content.ToString();

            var новыйОбъект = new ОбъектПозиция(new Объекты
            {
                ТипСтроения = selectedType,
                КоличествоКомнат = rooms,
                Метраж = metrazh,
                Стоимость = price
            });

            товары.Add(новыйОбъект); // Добавляем в коллекцию ObservableCollection
            магазин.ОбновитьРасчеты();
        }


        // Кнопка для удаления выбранных объектов
        private void btn_remove_file_Click(object sender, RoutedEventArgs e)
        {
            // Проверяем, есть ли выделенные элементы
            if (MainList.SelectedItems.Count == 0)
            {
                MessageBox.Show("Выделите объекты для удаления.", "Предупреждение");
                return;
            }

            // Подтверждаем удаление
            var result = MessageBox.Show("Вы уверены, что хотите удалить выбранные объекты?",
                                          "Подтверждение удаления",
                                          MessageBoxButton.YesNo,
                                          MessageBoxImage.Warning);

            if (result != MessageBoxResult.Yes)
            {
                return;
            }

            // Получаем список объектов, которые нужно удалить
            var itemsToRemove = MainList.SelectedItems.Cast<ОбъектПозиция>().ToList();

            // Удаляем объекты из коллекции
            var магазин = (Магазин)DataContext;
            foreach (var item in itemsToRemove)
            {
                магазин.СписокТоваров.Remove(item); // Удаляем объект из коллекции
            }

            MessageBox.Show("Выбранные объекты были удалены.");
            магазин.ОбновитьРасчеты();
        }

        // Кнопка для открытия файла
        private void btn_open_file_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog
            {
                Filter = "Text files (*.txt)|*.txt|JSON files (*.json)|*.json"
            };

            if (openFileDialog.ShowDialog() == true)
            {
                string fileExtension = Path.GetExtension(openFileDialog.FileName).ToLower();

                try
                {
                    if (fileExtension == ".txt")
                    {
                        List<Объекты> товарыИзФайла = ВсеОбъекты.ПолучитьВсеОбъектыИзФайла(openFileDialog.FileName);

                        if (товарыИзФайла.Count == 0)
                        {
                            MessageBox.Show("Нет товаров в файле!");
                            return;
                        }

                        ObservableCollection<ОбъектПозиция> позиции = new ObservableCollection<ОбъектПозиция>();
                        foreach (var t in товарыИзФайла)
                        {
                            позиции.Add(new ОбъектПозиция(t));
                        }

                        магазин.СписокТоваров.Clear();
                        foreach (var позиция in позиции)
                        {
                            магазин.СписокТоваров.Add(позиция);
                        }

                        магазин.ОбновитьРасчеты(); // ✅ обновление расчётов

                        MessageBox.Show("Данные успешно загружены из текстового файла.");
                    }
                    else if (fileExtension == ".json")
                    {
                        string json = File.ReadAllText(openFileDialog.FileName);
                        var товары = JsonSerializer.Deserialize<List<Объекты>>(json);

                        if (товары != null && товары.Count > 0)
                        {
                            ObservableCollection<ОбъектПозиция> позиции = new ObservableCollection<ОбъектПозиция>();
                            foreach (var t in товары)
                            {
                                позиции.Add(new ОбъектПозиция(t));
                            }

                            магазин.СписокТоваров.Clear();
                            foreach (var позиция in позиции)
                            {
                                магазин.СписокТоваров.Add(позиция);
                            }

                            магазин.ОбновитьРасчеты(); 

                            MessageBox.Show("Данные успешно загружены из JSON файла.");
                        }
                        else
                        {
                            MessageBox.Show("Нет корректных объектов в JSON файле!");
                        }
                    }
                    else
                    {
                        MessageBox.Show("Неподдерживаемый формат файла.");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка при открытии файла: {ex.Message}");
                }
            }
        }



        // Кнопка для сохранения данных в файл
        private void btn_save_file_Click(object sender, RoutedEventArgs e)
        {
            SaveFileDialog saveFileDialog = new SaveFileDialog
            {
                Filter = "Text files (*.txt)|*.txt"
            };

            if (saveFileDialog.ShowDialog() == true)
            {
                using (StreamWriter sw = new StreamWriter(saveFileDialog.FileName, false))
                {
                    foreach (var item in MainList.Items)
                    {
                        var объект = item as ОбъектПозиция;
                        if (объект != null)
                        {
                            string строкаДляЗаписи = $"{объект.ТипСтроения}*{объект.КоличествоКомнат}*{объект.Метраж}*{объект.Стоимость}";
                            sw.WriteLine(строкаДляЗаписи);
                        }
                    }
                }
                MessageBox.Show("Файл успешно сохранён.");
            }
        }

        // Кнопка для сохранения данных в формат JSON
        private void SaveToJson_Click(object sender, RoutedEventArgs e)
        {
            var магазин = (Магазин)DataContext;
            var список = магазин.СписокТоваров
                .Select(p => new Объекты
                {
                    ТипСтроения = p.ТипСтроения,
                    КоличествоКомнат = p.КоличествоКомнат,
                    Метраж = p.Метраж,
                    Стоимость = p.Стоимость
                }).ToList();

            SaveFileDialog saveDialog = new SaveFileDialog
            {
                Filter = "JSON файлы (*.json)|*.json"
            };

            if (saveDialog.ShowDialog() == true)
            {
                var options = new JsonSerializerOptions
                {
                    WriteIndented = true,
                    Encoder = System.Text.Encodings.Web.JavaScriptEncoder.UnsafeRelaxedJsonEscaping
                };

                string json = JsonSerializer.Serialize(список, options);
                File.WriteAllText(saveDialog.FileName, json, Encoding.UTF8);

                MessageBox.Show("Файл сохранён в формате JSON!");
            }
        }

    }
}
