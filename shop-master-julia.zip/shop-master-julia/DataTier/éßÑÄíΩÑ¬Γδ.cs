﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Text.Json;

namespace DataTier
{
    public static class ВсеОбъекты
    {
        // Чтение из .txt файла с разделителем '*'
        public static List<Объекты> ПолучитьВсеОбъектыИзФайла(string путь)
        {
            List<Объекты> список = new List<Объекты>();

            try
            {
                var строки = File.ReadAllLines(путь);

                foreach (var строка in строки)
                {
                    var части = строка.Split('*');

                    if (части.Length == 4)
                    {
                        try
                        {
                            string тип = части[0].Trim();
                            int комнаты = int.Parse(части[1].Trim());
                            int метраж = int.Parse(части[2].Trim());
                            int стоимость = int.Parse(части[3].Trim());

                            список.Add(new Объекты
                            {
                                ТипСтроения = тип,
                                КоличествоКомнат = комнаты,
                                Метраж = метраж,
                                Стоимость = стоимость
                            });
                        }
                        catch
                        {
                            MessageBox.Show($"Ошибка при парсинге строки: {строка}");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка чтения файла: {ex.Message}");
            }

            return список;
        }

        // Сохранение объектов в JSON файл в правильном формате
        public static void СохранитьВJson(List<Объекты> список, string путь)
        {
            try
            {
                var options = new JsonSerializerOptions
                {
                    WriteIndented = true // форматированный (красивый) JSON
                };

                string json = JsonSerializer.Serialize(список, options);
                File.WriteAllText(путь, json, Encoding.UTF8);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при сохранении JSON: {ex.Message}");
            }
        }
        public static List<Объекты> НайтиОбъектыПоКлючу(string путьКФайлу, string ключ, string значение)
        {
            // Загружаем все объекты из файла
            var всеОбъекты = ВсеОбъекты.ПолучитьВсеОбъектыИзФайла(путьКФайлу);

            // Ищем объекты в зависимости от ключа
            return ключ.ToLower() switch
            {
                "типстроения" => всеОбъекты.Where(obj => obj.ТипСтроения.Contains(значение, StringComparison.OrdinalIgnoreCase)).ToList(),
                "количествокомнат" when int.TryParse(значение, out var комнаты) =>
                    всеОбъекты.Where(obj => obj.КоличествоКомнат == комнаты).ToList(),
                "метраж" when int.TryParse(значение, out var метраж) =>
                    всеОбъекты.Where(obj => obj.Метраж == метраж).ToList(),
                "стоимость" when int.TryParse(значение, out var стоимость) =>
                    всеОбъекты.Where(obj => obj.Стоимость == стоимость).ToList(),
                _ => new List<Объекты>() // Если ключ не найден, возвращаем пустой список
            };
        }
    }
}



