﻿namespace DataTier
{
    public class Объекты
    {
        public string ТипСтроения { get; set; }
        public int КоличествоКомнат { get; set; }
        public int Метраж { get; set; }
        public int Стоимость { get; set; }

        public string ПредставлениеТовара
        {
            get
            {
                return $"{ТипСтроения} : {КоличествоКомнат} комнат, {Метраж} м², {Стоимость} руб.";
            }
        }
    }
}
