﻿

namespace DataTier
{
    public class Объекты
     {
            public String ТипСтроения { get; set; }
            public int КоличествоКомнат { get; set; }
            public int Метраж { get; set; }
            public int Стоимость { get; set; }
    }

    }
    


