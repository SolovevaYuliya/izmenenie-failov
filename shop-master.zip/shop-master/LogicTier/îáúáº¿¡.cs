﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataTier;

namespace LogicTier
{
    public class Магазин
    {
        private List<ТоварнаяПозиация> _товары = new List<ТоварнаяПозиация>();
        public string ОбъектСМаксимальнойСтоимостьюКМ { get; set; }
        public string СредняяСтоимостьКМДляКвартир { get; set; }
        public Магазин(List<ТоварнаяПозиация> позиции)
        {
            _товары = позиции;
            var объектСМаксСтоимостью = ОбъектСМаксСтоимостьюКМ();
            var средняяСтоимостьКМ = СредняяСтоимостьКвадратногоМетераДляКвартир();
            _товары = позиции;
            ОбъектСМаксимальнойСтоимостьюКМ = ОбъектСМаксСтоимостьюКМ();
            СредняяСтоимостьКМДляКвартир = СредняяСтоимостьКвадратногоМетераДляКвартир().ToString("F2");

  

        }

        public List<ТоварнаяПозиация> СписокТоваров
        {
            get { return _товары; }
        }

        public string НаименованиеМагазина
        {
            get { return "Наш магазин"; }

        }
        public string ОбъектСМаксСтоимостьюКМ()
        {
            if (_товары.Count == 0)
                return "Нет объектов";

            var maxItem = _товары.First();
            double maxznach = maxItem.Стоимость / (double)maxItem.Метраж;

            foreach (var item in _товары)
            {
                double right_znach = item.Стоимость / (double)item.Метраж;
                if (right_znach > maxznach)
                {
                    maxznach = right_znach;
                    maxItem = item;
                }
            }

            return maxItem.ПредставлениеТовара;
        }
        public double СредняяСтоимостьКвадратногоМетераДляКвартир()
        {
            var квартиры = _товары.Where(t => t.ТипСтроения.ToLower() == "квартира").ToList();
            if (квартиры.Count == 0)
                return 0;

            double result = квартиры.Sum(t => (double)t.Стоимость / t.Метраж);
            return result / квартиры.Count;
            
        }

    }
}
