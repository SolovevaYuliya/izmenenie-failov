﻿using System;
using System.Collections.ObjectModel;
using System.IO;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using DataTier;
using LogicTier;
using MathNet.Numerics;
using Microsoft.Win32;
using Window = System.Windows.Window;

namespace PresentationTier;

/// <summary>
/// Interaction logic for MainWindow.xaml
/// </summary>
public partial class MainWindow : Window
{
    private Магазин магазин;

    public MainWindow()
    {
        InitializeComponent();


    }
    private string selectedFilePath;
    private void BtnAddItem_Click(object sender, RoutedEventArgs e)

    {
        Microsoft.Win32.SaveFileDialog saveFileDialog = new Microsoft.Win32.SaveFileDialog();
        saveFileDialog.Filter = "Text files (*.txt)|*.txt|All files (*.*)|*.*";
        saveFileDialog.Title = "Выберите файл для сохранения";

        if (saveFileDialog.ShowDialog() == true)
        {
            selectedFilePath = saveFileDialog.FileName;
            MessageBox.Show($"Файл выбран: {selectedFilePath}");
        }
        string ТипСтроения = NewComboBox.Text;
        string КоличествоКомнат = CountRooms.Text;
        string Метраж = Metrazh.Text;
        string Стоимость = Price.Text;

        // Проверяем, что все поля заполнены
        if (string.IsNullOrWhiteSpace(ТипСтроения) ||
            string.IsNullOrWhiteSpace(КоличествоКомнат) ||
            string.IsNullOrWhiteSpace(Метраж) ||
            string.IsNullOrWhiteSpace(Стоимость))
        {
            MessageBox.Show("Пожалуйста, заполните все поля.");
            return;
        }
        string строкаДляЗаписи = $"{ТипСтроения}*{КоличествоКомнат}*{Метраж}*{Стоимость}";

        File.AppendAllText(selectedFilePath, строкаДляЗаписи + Environment.NewLine);


        CountRooms.Clear();
        Metrazh.Clear();
        Price.Clear();
    }

    // Открытие файла (реализовано ранее)
    private void btn_open_file_Click(object sender, RoutedEventArgs e)
    {
        List<Объекты> товарыИзФайла = ВсеОбъекты.ПолучитьВсеОбъектыИзФайла();

        if (товарыИзФайла.Count == 0)
        {
            MessageBox.Show("Нет товаров в файле!");
            return;
        }

        ObservableCollection<ОбъектПозиция> позиции = new ObservableCollection<ОбъектПозиция>();
        foreach (var t in товарыИзФайла)
        {
            позиции.Add(new ОбъектПозиция(t));
        }

        магазин = new Магазин(позиции);
        this.DataContext = магазин; // Обновляем DataContext
    }
    private void ComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (NewComboBox.SelectedItem != null)
        {
            var selectedItem = (System.Windows.Controls.ComboBoxItem)NewComboBox.SelectedItem;

        }
    }
    private void BtnCreateFile_Click(object sender, RoutedEventArgs e)
    {

    }
}
