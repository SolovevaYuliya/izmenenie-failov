﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataTier
{
    public class ВсеОбъекты
    {
        public static void СохранитьВсеТовары(List<Объекты> товары)
        {

        }
        public static List<Объекты> ПолучитьВсеОбъектыИзФайла()
        {
            List<Объекты> list = new List<Объекты>();

            OpenFileDialog openFileDialog = new OpenFileDialog();

            if (openFileDialog.ShowDialog() == true)
            {
                string FilePath = openFileDialog.FileName;
                using (StreamReader sreader = new StreamReader(FilePath, Encoding.UTF8))
                {
                    while (!sreader.EndOfStream) // пока не конец потока

                    {
                        string[] line = sreader.ReadLine().Split("*");
                        
                        Объекты tovar = new Объекты()
                        {
                            ТипСтроения = line[0],
                            КоличествоКомнат = int.Parse(line[1]),
                            Метраж = int.Parse(line[2]),
                            Стоимость = int.Parse(line[3])

                        };
                        list.Add(tovar);
                    }
                }

            }
            return list;
        }
      
    }
}
