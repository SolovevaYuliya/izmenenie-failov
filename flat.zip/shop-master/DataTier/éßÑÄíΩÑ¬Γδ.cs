﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace DataTier
{
    public class ВсеОбъекты
    {
        public static void СохранитьВсеТовары(List<Объекты> товары)
        {

        }
        public static List<Объекты> ПолучитьВсеОбъектыИзФайла()
        {
            List<Объекты> list = new List<Объекты>();

            OpenFileDialog openFileDialog = new OpenFileDialog();

            if (openFileDialog.ShowDialog() == true)
            {
                string FilePath = openFileDialog.FileName;
                using (StreamReader sreader = new StreamReader(FilePath, Encoding.UTF8))
                {
                    while (!sreader.EndOfStream) // Пока не достигнут конец файла
                    {
                        string[] line = sreader.ReadLine().Split("*"); // Разделяем строку по символу '*'

                        if (line.Length == 4) // Проверяем, что в строке 4 элемента
                        {
                            try
                            {
                                // Создаем объект из прочитанных данных
                                Объекты tovar = new Объекты()
                                {
                                    ТипСтроения = line[0], // Строка
                                    КоличествоКомнат = int.Parse(line[1]), // Целое число
                                    Метраж = int.Parse(line[2]), // Целое число
                                    Стоимость = int.Parse(line[3]) // Целое число
                                };

                                list.Add(tovar); // Добавляем объект в список
                            }
                            catch (FormatException)
                            {
                                MessageBox.Show("Ошибка формата данных в файле. Проверьте содержимое.");
                            }
                        }
                        else
                        {
                            MessageBox.Show("Ошибка: некорректное количество данных в строке.");
                        }
                    }
                }
            }
            return list;
        }
    }
}
